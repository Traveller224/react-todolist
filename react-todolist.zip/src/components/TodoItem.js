import React from "react"

function TodoItem(props){
	const completedStyle = {
		fontStyle:"italic",
		color:"#82a549",
		textDecoration:"line-through"
	}
	return (
		<div className="todo-item">
			<div style={{display:"flex"}}>
				<input type="checkbox" checked={props.item.completed} onChange={() => props.handleChange(props.item.id)}/>
				<p style={props.item.completed ? completedStyle: null}>{props.item.text}</p>
			</div>
			<button style={{position:"right"}} onClick={() => {props.deleteTodo(props.item.id);}}>Del me</button>
		</div>
	)
}

export default TodoItem
