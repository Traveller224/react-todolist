import React from "react"
import "./Header.css"

function Header(){
	return (
		<header className="navbar">This is the header</header>
	)
}

export default Header
